## 使用说明

本说明介绍如何使用本项目中的启动雷达建图、导航的功能


### 1. 构建与环境设置
首次或更新源码后进行编译，并在当前终端加载环境：

```bash
cd /home/jetson/2D_car_ws
colcon build --symlink-install
source /home/jetson/2D_car_ws/install/setup.bash
```

---

### 2. 雷达接口、小车接口权限

```bash
sudo chmod 666 /dev/ttyUSB0   #这个是雷达接口
sudo chmod 666 /dev/ttyACM0  #这个是底盘小车的接口
```

---

### 3. 启动建图

1）开始建图
```bash
ros2 launch turn_on_dlrobot_robot gmapping_demo.launch.py
```
2）启动rviz可视化
```bash
rviz2 (另外开一个终端)
```
3）保存地图
```bash
ros2 run nav2_map_server map_saver_cli -f /home/jetson/1_ws/src/turn_on_dlrobot_robot/maps/test_map_210 (另外开一个终端)
```
# "/home/jetson/1_ws/src/turn_on_dlrobot_robot/maps/test_map_210" 这个为保存地图的绝对路径
---


### 4. 开始导航

```bash
ros2 launch turn_on_dlrobot_robot navigation_demo.launch.py map:=//home/jetson/1_ws/src/turn_on_dlrobot_robot/maps/newest1_map_214.yaml
```
# "map:="这后面跟的是你保存的地图

