import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    package_dir = get_package_share_directory('serial_command_sender')
    
    serial_port = LaunchConfiguration('serial_port', default='/dev/ttyUSB0')
    serial_baudrate = LaunchConfiguration('serial_baudrate', default=115200)
    
    declare_serial_port = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/ttyUSB0',
        description='Serial port to use')
        
    declare_serial_baudrate = DeclareLaunchArgument(
        'serial_baudrate',
        default_value='115200',
        description='Baud rate of serial port')
    
    serial_sender_node = Node(
        package='serial_command_sender',
        executable='serial_sender',
        name='serial_command_sender',
        parameters=[{
            'serial_port': serial_port,
            'serial_baudrate': serial_baudrate
        }],
        output='screen')
    
    return LaunchDescription([
        declare_serial_port,
        declare_serial_baudrate,
        serial_sender_node
    ])
