#ifndef SERIAL_COMMAND_SENDER__SERIAL_SENDER_HPP_
#define SERIAL_COMMAND_SENDER__SERIAL_SENDER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/msg/float32_multi_array.hpp>
#include <string>
#include <vector>
#include <map>

namespace serial_command_sender
{

class SerialSender : public rclcpp::Node
{
public:
  explicit SerialSender(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void command_callback(const std_msgs::msg::String::SharedPtr msg);
  void target_callback(const std_msgs::msg::Float32MultiArray::SharedPtr msg);
  
  // Convert string to binary data
  std::vector<uint8_t> string_to_binary(const std::string& str);
  
  // Send binary data via serial
  void send_via_serial(const std::vector<uint8_t>& data);
  
  // Configure serial port
  bool configure_serial_port();

  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr command_sub_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr target_sub_;
  
  std::string serial_port_;
  int serial_baudrate_;
  int serial_fd_;  // file descriptor for serial port
  
  // Map to store last command sent to each servo
  std::map<int, std::string> last_commands_;
};

}  // namespace serial_command_sender

#endif  // SERIAL_COMMAND_SENDER__SERIAL_SENDER_HPP_
