#include "serial_command_sender/serial_sender.hpp"
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <map>

namespace serial_command_sender
{

SerialSender::SerialSender(const rclcpp::NodeOptions & options)
: Node("serial_command_sender", options), serial_fd_(-1)
{
  // Declare and get parameters
  serial_port_ = this->declare_parameter<std::string>("serial_port", "/dev/ttyUSB0");
  serial_baudrate_ = this->declare_parameter<int>("serial_baudrate", 115200);
  
  // Initialize and configure serial port
  if (!configure_serial_port()) {
    RCLCPP_ERROR(this->get_logger(), "Failed to configure serial port: %s", serial_port_.c_str());
    return;
  }
  
  // Create subscribers
  command_sub_ = this->create_subscription<std_msgs::msg::String>(
    "serial_command", 10, 
    std::bind(&SerialSender::command_callback, this, std::placeholders::_1));
    
  target_sub_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
    "target_generate", 10,
    std::bind(&SerialSender::target_callback, this, std::placeholders::_1));
    
  RCLCPP_INFO(this->get_logger(), "Serial command sender initialized");
  RCLCPP_INFO(this->get_logger(), "Listening on topic: serial_command");
  RCLCPP_INFO(this->get_logger(), "Listening on topic: target_generate");
  RCLCPP_INFO(this->get_logger(), "Serial port: %s, Baud rate: %d", 
              serial_port_.c_str(), serial_baudrate_);
}

bool SerialSender::configure_serial_port()
{
  // Open serial port
  serial_fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
  if (serial_fd_ == -1) {
    RCLCPP_ERROR(this->get_logger(), "Failed to open serial port: %s", serial_port_.c_str());
    return false;
  }
  
  // Configure serial port
  struct termios options;
  tcgetattr(serial_fd_, &options);
  
  // Set input and output baud rate
  switch(serial_baudrate_) {
    case 9600:
      cfsetispeed(&options, B9600);
      cfsetospeed(&options, B9600);
      break;
    case 19200:
      cfsetispeed(&options, B19200);
      cfsetospeed(&options, B19200);
      break;
    case 38400:
      cfsetispeed(&options, B38400);
      cfsetospeed(&options, B38400);
      break;
    case 57600:
      cfsetispeed(&options, B57600);
      cfsetospeed(&options, B57600);
      break;
    case 115200:
      cfsetispeed(&options, B115200);
      cfsetospeed(&options, B115200);
      break;
    default:
      RCLCPP_WARN(this->get_logger(), "Unsupported baud rate: %d, using default 115200", serial_baudrate_);
      cfsetispeed(&options, B115200);
      cfsetospeed(&options, B115200);
      break;
  }
  
  // Configure for raw input/output
  options.c_cflag |= (CLOCAL | CREAD);    // Enable receiver, set local
  options.c_cflag &= ~PARENB;             // No parity
  options.c_cflag &= ~CSTOPB;             // 1 stop bit
  options.c_cflag &= ~CSIZE;              // Mask character size bits
  options.c_cflag |= CS8;                 // 8 data bits
  
  // Enable raw input
  options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  
  // Enable raw output
  options.c_oflag &= ~OPOST;
  
  // Set read behavior
  options.c_cc[VMIN] = 0;   // Minimum number of characters to read
  options.c_cc[VTIME] = 10; // Time to wait for data (tenths of seconds)
  
  // Apply settings
  tcflush(serial_fd_, TCIFLUSH);
  if (tcsetattr(serial_fd_, TCSANOW, &options) != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to set serial port attributes");
    close(serial_fd_);
    serial_fd_ = -1;
    return false;
  }
  
  return true;
}

void SerialSender::command_callback(const std_msgs::msg::String::SharedPtr msg)
{
  RCLCPP_INFO(this->get_logger(), "Received command: %s", msg->data.c_str());
  
  // Convert string to binary
  std::vector<uint8_t> binary_data = string_to_binary(msg->data);
  
  // Send via serial
  send_via_serial(binary_data);
}

void SerialSender::target_callback(const std_msgs::msg::Float32MultiArray::SharedPtr msg)
{
  RCLCPP_INFO(this->get_logger(), "Received target data with %zu elements", msg->data.size());
  
  // Process the received data
  // Assuming pairs of variable ID and value
  for (size_t i = 0; i < msg->data.size(); i += 2) {
    if (i + 1 < msg->data.size()) {
      // First element is variable ID, second is angle value
      int var_id = static_cast<int>(msg->data[i]);
      float theta1 = msg->data[i+1];
      
      // Set initial PWM value for servo 001 to 1500 (180 degrees)
      int base_pwm = (var_id == 1) ? 1500 : 500;
      
      // Calculate new PWM value using the new formula
      // a = pwm + theta1 * 2000 / 360
      float a = base_pwm + theta1 * 2000.0 / 360.0;
      int pwm_value;
      
      if (a < 500) {
        // When a < 500, use formula: pwm = 2000 + a
        pwm_value = 2000 + static_cast<int>(a);
      } else {
        // Otherwise, use formula: pwm = a % 2500
        pwm_value = static_cast<int>(a) % 2500;
      }
      
      // Ensure PWM value is within valid range (typically 500-2500 for servos)
      pwm_value = std::max(500, std::min(2500, pwm_value));
      
      // Format: #xxxPxxxxTxxxx! where xxx is 3-digit servo ID, xxxx is 4-digit PWM value, xxxx is 4-digit time
      std::stringstream ss;
      ss << "#" << std::setfill('0') << std::setw(3) << var_id 
         << "P" << std::setfill('0') << std::setw(4) << pwm_value 
         << "T" << std::setfill('0') << std::setw(4) << 1000 << "!";  // Fixed time value 1000
      
      std::string command = ss.str();
      
      // Check if this command is different from the last one sent for this servo
      if (last_commands_[var_id] != command) {
        RCLCPP_INFO(this->get_logger(), "Generated command: %s (from ID: %d, theta1: %.2f, PWM: %d)", 
                    command.c_str(), var_id, theta1, pwm_value);
        
        // Store the last command for this servo
        last_commands_[var_id] = command;
        
        // Convert to binary and send via serial
        std::vector<uint8_t> binary_data(command.begin(), command.end());
        send_via_serial(binary_data);
      } else {
        RCLCPP_DEBUG(this->get_logger(), "Skipping duplicate command for servo %d", var_id);
      }
    }
  }
}

std::vector<uint8_t> SerialSender::string_to_binary(const std::string& str)
{
  // Convert string to binary data (uint8_t vector)
  std::vector<uint8_t> binary_data(str.begin(), str.end());
  return binary_data;
}

void SerialSender::send_via_serial(const std::vector<uint8_t>& data)
{
  if (serial_fd_ == -1) {
    RCLCPP_ERROR(this->get_logger(), "Serial port not open");
    return;
  }
  
  ssize_t bytes_written = write(serial_fd_, data.data(), data.size());
  if (bytes_written < 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to write to serial port");
  } else if (static_cast<size_t>(bytes_written) != data.size()) {
    RCLCPP_WARN(this->get_logger(), "Incomplete write to serial port. "
               "Expected: %zu bytes, Written: %zd bytes", data.size(), bytes_written);
  } else {
    RCLCPP_INFO(this->get_logger(), "Successfully sent %zd bytes via serial", bytes_written);
  }
  
  // Flush the output buffer
  tcdrain(serial_fd_);
}

} // namespace serial_command_sender
