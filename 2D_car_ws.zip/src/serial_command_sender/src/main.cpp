#include "serial_command_sender/serial_sender.hpp"
#include <memory>

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<serial_command_sender::SerialSender>());
  rclcpp::shutdown();
  return 0;
}
