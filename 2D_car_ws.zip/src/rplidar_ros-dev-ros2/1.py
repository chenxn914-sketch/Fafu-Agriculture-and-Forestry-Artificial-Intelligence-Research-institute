import serial
import struct
import time
import numpy as np
import matplotlib.pyplot as plt
import signal
import sys
import atexit

PORT = '/dev/ttyUSB0'  # 根据实际情况修改
BAUDRATE = 115200

CMD_STOP = 0x25
CMD_SCAN = 0x20
CMD_GET_INFO = 0x50
CMD_GET_HEALTH = 0x52
CMD_RESET = 0x40
CMD_SET_PWM = 0xF0

ser = None

# 发送单字节命令
def send_cmd(cmd):
    global ser
    if ser is not None:
        ser.write(bytes([0xA5, cmd]))
        print(f"[调试] 已发送命令: 0xA5 0x{cmd:02X}")

# 获取设备信息
def get_device_info():
    send_cmd(CMD_GET_INFO)
    header = ser.read(7)
    print("[调试] 设备信息应答头:", header.hex())
    if header[:2] != b'\xA5\x5A':
        print("设备信息应答头错误:", header)
        return None
    payload = ser.read(20)
    print("设备信息:", payload.hex())
    return payload

# 获取健康信息
def get_health():
    send_cmd(CMD_GET_HEALTH)
    header = ser.read(7)
    print("[调试] 健康信息应答头:", header.hex())
    if header[:2] != b'\xA5\x5A':
        print("健康信息应答头错误:", header)
        return None
    payload = ser.read(3)
    print("健康信息:", payload.hex())
    return payload

# 停止扫描
def stop_scan():
    send_cmd(CMD_STOP)
    time.sleep(0.1)
    print("[调试] 已发送停止命令")

# 启动扫描
def start_scan():
    send_cmd(CMD_SCAN)
    header = ser.read(7)
    print("[调试] 扫描应答头:", header.hex())
    if header[:2] != b'\xA5\x5A':
        print("扫描应答头错误:", header)
        return False
    if header[6] != 0x81:
        print("扫描应答类型错误，type=", header[6])
        return False
    print("[调试] 扫描应答头正确，进入数据接收阶段")
    return True

# 复位雷达
def reset_lidar():
    send_cmd(CMD_RESET)
    time.sleep(0.2)
    print("[调试] 已发送复位命令")

# 解析单个点数据
def parse_scan_data(data):
    if len(data) != 5:
        return None
    sync_quality = data[0]
    angle_q6_checkbit = data[1] | ((data[2] & 0x7F) << 8)
    distance_q2 = data[3] | (data[4] << 8)
    start_flag = (sync_quality & 0x01)
    inv_start_flag = (sync_quality & 0x02) >> 1
    quality = sync_quality >> 2
    angle = (angle_q6_checkbit >> 1) / 64.0
    distance = distance_q2 / 4.0  # mm
    return start_flag, inv_start_flag, angle, distance, quality

# 设置电机PWM
def set_motor_pwm(pwm=660):
    # 0xA5 0xF0 + 2字节pwm + 校验和
    payload = struct.pack('<H', pwm)
    checksum = (CMD_SET_PWM ^ payload[0] ^ payload[1]) & 0xFF
    cmd = bytes([0xA5, CMD_SET_PWM]) + payload + bytes([checksum])
    ser.write(cmd)
    print(f"[调试] 已发送电机PWM命令，PWM={pwm}")

# 退出清理，恢复电机
def cleanup():
    global ser
    print("\n[清理] 正在尝试恢复雷达电机转动...")
    try:
        reset_lidar()
        time.sleep(0.2)
        set_motor_pwm(660)
        time.sleep(0.2)
        start_scan()
        time.sleep(0.2)
        if ser is not None:
            ser.close()
        print("[清理] 雷达已恢复转动，串口已关闭。")
    except Exception as e:
        print("[清理] 退出时发生异常：", e)

# 信号处理
def signal_handler(sig, frame):
    print("\n[信号] 捕获到退出信号，准备退出...")
    cleanup()
    sys.exit(0)

# 主程序
def main():
    global ser
    ser = serial.Serial(PORT, BAUDRATE, timeout=1)
    time.sleep(2)
    print("获取设备信息...")
    get_device_info()
    print("获取健康信息...")
    get_health()
    print("设置电机PWM...")
    set_motor_pwm(660)
    time.sleep(0.1)
    # print("发送停止命令...")
    # stop_scan()
    # time.sleep(0.1)
    print("发送扫描命令...")
    if not start_scan():
        print("启动扫描失败")
        return

    print("开始接收扫描数据（Ctrl+C停止）...")
    angles = []
    distances = []
    point_count = 0
    try:
        while True:
            data = ser.read(5)
            print(f"[调试] 尝试读取数据，长度: {len(data)}")
            if len(data) != 5:
                continue
            print("[调试] 收到数据:", data.hex())
            result = parse_scan_data(data)
            if result is None:
                continue
            start_flag, inv_start_flag, angle, distance, quality = result
            if start_flag == 1 and angles and distances:
                print(f"[调试] 新一圈点云，共{len(angles)}个点，刷新图像")
                plt.clf()
                x = np.array(distances) * np.cos(np.deg2rad(angles))
                y = np.array(distances) * np.sin(np.deg2rad(angles))
                plt.scatter(x, y, s=2)
                plt.title("RPLIDAR A1 扫描点云")
                plt.axis('equal')
                plt.pause(0.01)
                angles = []
                distances = []
            if distance > 0:
                angles.append(angle)
                distances.append(distance)
            point_count += 1
            if point_count % 100 == 0:
                print(f"[调试] 已累计接收{point_count}个点")
    except Exception as e:
        print("主循环异常：", e)
        cleanup()
    finally:
        cleanup()

if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)   # Ctrl+C
    signal.signal(signal.SIGTERM, signal_handler)  # kill
    atexit.register(cleanup)
    main() 