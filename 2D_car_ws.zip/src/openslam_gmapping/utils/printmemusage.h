#ifndef PRINTMEMUSAGE_H
#define PRINTMEMUSAGE_H
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <string>

namespace GMapping{
	void printmemusage();
};

#endif
