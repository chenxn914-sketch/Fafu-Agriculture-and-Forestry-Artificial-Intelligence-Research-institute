from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 声明参数
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation time if true'
        ),
        
        # 启动底盘驱动（tank.launch.py）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'tank.launch.py'
                ])
            ]),
            launch_arguments={
                'akmcar': 'false'
            }.items()
        ),
        
        # 启动A1雷达
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('rplidar_ros'),
                    'launch',
                    'rplidar_a1_launch.py'
                ])
            ]),
            launch_arguments={
                'serial_port': '/dev/ttyUSB0',
                'serial_baudrate': '115200',
                'frame_id': 'laser',
                'inverted': 'false',
                'angle_compensate': 'true'
            }.items()
        ),
        # 参数说明：[x, y, z, roll, pitch, yaw, parent_frame, child_frame]
        # 当前配置：雷达在机器人中心上方0.1米处
        # 如需调整，请修改以下参数：
        # x: 前后偏移（正数向前，负数向后）
        # y: 左右偏移（正数向左，负数向右）  
        # z: 高度偏移（正数向上，负数向下）
        # roll, pitch, yaw: 旋转角度（弧度）
        # 发布静态TF变换
        # base_footprint -> base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='basefootprint_to_baselink',
            arguments=['0', '0', '0', '0', '0', '0', 'base_footprint', 'base_link'],
            output='screen'
        ),
        # base_link -> laser
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='laser_to_base_link',
            arguments=['0', '0', '0.4', '0', '0', '0', 'base_link', 'laser'],
            output='screen'
        ),
        
        # 启动gmapping SLAM
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('slam_gmapping'),
                    'launch',
                    'gmapping_launch.py'
                ])
            ]),
            launch_arguments={
                'use_sim_time': LaunchConfiguration('use_sim_time')
            }.items()
        ),
    ]) 