from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition
from launch.conditions import UnlessCondition
import launch_ros.actions

#def launch(launch_descriptor, argv):# ROS 2 启动文件主函数，返回一个 LaunchDescription 对象
def generate_launch_description():

    # 定义启动参数 akmcar，表示是否使用 Ackermann 转向（默认是 false）
    akmcar = LaunchConfiguration('akmcar', default='false')
    return LaunchDescription([
        # 声明参数 akmcar，使用户可以通过命令行传入该参数        
        DeclareLaunchArgument(
            'akmcar',
            default_value='false',
            description='Use simulation (Gazebo) clock if true'),# 描述可以根据具体用途修改
#the default mode is akm
        # 如果 akmcar 为 true，启动带 Ackermann 支持的主控制节点
        launch_ros.actions.Node(
            condition=IfCondition(akmcar),
            package='turn_on_dlrobot_robot',  # 包名
            executable='dlrobot_robot_node',  # 可执行文件名
            parameters=[{'usart_port_name': '/dev/ttyACM0',# 串口设备名
                'serial_baud_rate': 115200,# 波特率
                'robot_frame_id': 'base_footprint',# 机器人坐标系
                'odom_frame_id': 'odom',  # 里程计坐标系
                'cmd_vel': 'cmd_vel',    # 速度话题名
                'akm_cmd_vel': 'ackermann_cmd',  # Ackermann控制话题
                'product_number': 0,}],  # 产品编号
            remappings=[('/cmd_vel', 'cmd_vel'),]),# 话题重映射
        # 如果 akmcar 为 true，启动 cmd_vel 转 Ackermann 驱动节点
        launch_ros.actions.Node(
            condition=IfCondition(akmcar),
            package='turn_on_dlrobot_robot', 
            executable='cmd_vel_to_ackermann_drive.py', # Python 脚本形式的节点
            name='cmd_vel_to_ackermann_drive',# 节点名称
            output='screen'),# 输出到屏幕，便于调试
#the default mode is not akm
        # 如果 akmcar 为 false，启动不带 Ackermann 支持的主控制节点
        launch_ros.actions.Node(
            condition=UnlessCondition(akmcar), # akmcar 为 false 时才启动
            package='turn_on_dlrobot_robot', 
            executable='dlrobot_robot_node', 
            parameters=[{'usart_port_name': '/dev/ttyACM0',
                'serial_baud_rate': 115200,
                'robot_frame_id': 'base_footprint',
                'odom_frame_id': 'odom',
                'cmd_vel': 'cmd_vel',
                'akm_cmd_vel': 'none', # 关闭 Ackermann 支持
                'product_number': 0,}],
            )

  ])
