from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turn_on_dlrobot_robot',  # 替换为你自己的包名
            executable='keyboard_control_node',
            name='keyboard_control',
            output='screen'
        )
    ])
