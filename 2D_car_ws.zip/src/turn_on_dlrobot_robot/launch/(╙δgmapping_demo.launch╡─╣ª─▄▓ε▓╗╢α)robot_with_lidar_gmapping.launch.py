from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare
from launch.conditions import IfCondition

def generate_launch_description():
    return LaunchDescription([
        # 声明参数
        DeclareLaunchArgument(
            'akmcar',
            default_value='false',
            description='Use Ackermann steering mode if true'
        ),
        DeclareLaunchArgument(
            'lidar_type',
            default_value='a1',
            description='Type of lidar (a1, a2, s2, c1, a3)'
        ),
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation time if true'
        ),
        
        # 启动底盘驱动（tank.launch.py）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'tank.launch.py'
                ])
            ]),
            launch_arguments={
                'akmcar': LaunchConfiguration('akmcar')
            }.items()
        ),
        
        # 启动A1雷达
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('rplidar_ros'),
                    'launch',
                    'rplidar_a1_launch.py'
                ])
            ]),
            launch_arguments={
                'serial_port': '/dev/ttyUSB0',
                'serial_baudrate': '115200',
                'frame_id': 'laser',
                'inverted': 'false',
                'angle_compensate': 'true'
            }.items(),
            condition=IfCondition(LaunchConfiguration('lidar_type').equals('a1'))
        ),
        
        # 启动静态TF发布器
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'static_tf.launch.py'
                ])
            ])
        ),
        
        # 启动gmapping SLAM
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('slam_gmapping'),
                    'launch',
                    'gmapping_launch.py'
                ])
            ]),
            launch_arguments={
                'use_sim_time': LaunchConfiguration('use_sim_time')
            }.items()
        ),
    ]) 