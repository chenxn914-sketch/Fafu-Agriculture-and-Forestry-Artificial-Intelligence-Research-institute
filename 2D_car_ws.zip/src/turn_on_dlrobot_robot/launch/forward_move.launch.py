from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 只启动速度发布节点（forward_move_node）
        Node(
            package='turn_on_dlrobot_robot',
            executable='forward_move_node',
            name='forward_move_node',
            output='screen',                        # 输出到屏幕
        ),
    ]) 