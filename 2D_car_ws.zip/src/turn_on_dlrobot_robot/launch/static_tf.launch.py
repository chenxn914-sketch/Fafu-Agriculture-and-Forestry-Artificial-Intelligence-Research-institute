from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 发布激光雷达到机器人的静态TF变换
        # 假设激光雷达安装在机器人中心上方，高度为0.1米
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='laser_to_base_footprint',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_footprint', 'laser'],
            output='screen'
        ),
        
        # 发布base_footprint到base_link的变换（如果需要）
        # 注释掉，因为我们统一使用base_footprint
        # Node(
        #     package='tf2_ros',
        #     executable='static_transform_publisher',
        #     name='base_footprint_to_base_link',
        #     arguments=['0', '0', '0', '0', '0', '0', 'base_footprint', 'base_link'],
        #     output='screen'
        # ),
    ]) 