from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    return LaunchDescription([
        # 声明参数
        DeclareLaunchArgument(
            'akmcar',
            default_value='false',
            description='Use Ackermann steering mode if true'
        ),
        DeclareLaunchArgument(
            'linear_speed',
            default_value='0.1',
            description='Linear speed for forward/backward movement (m/s)'
        ),
        DeclareLaunchArgument(
            'angular_speed',
            default_value='0.5',
            description='Angular speed for turning (rad/s)'
        ),
        DeclareLaunchArgument(
            'lateral_speed',
            default_value='0.05',
            description='Lateral speed for side movement (m/s)'
        ),
        
        # 启动底盘驱动（tank.launch.py）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'tank.launch.py'
                ])
            ]),
            launch_arguments={
                'akmcar': LaunchConfiguration('akmcar')
            }.items()
        ),
        
        # 启动Python版本的移动控制
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'movement_control_python.launch.py'
                ])
            ]),
            launch_arguments={
                'linear_speed': LaunchConfiguration('linear_speed'),
                'angular_speed': LaunchConfiguration('angular_speed'),
                'lateral_speed': LaunchConfiguration('lateral_speed'),
            }.items()
        ),
    ]) 