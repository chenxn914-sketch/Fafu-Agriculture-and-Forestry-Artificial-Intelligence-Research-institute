from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 声明参数
        DeclareLaunchArgument(
            'linear_speed',
            default_value='0.1',
            description='Linear speed for forward/backward movement (m/s)'
        ),
        DeclareLaunchArgument(
            'angular_speed',
            default_value='0.5',
            description='Angular speed for turning (rad/s)'
        ),
        DeclareLaunchArgument(
            'lateral_speed',
            default_value='0.05',
            description='Lateral speed for side movement (m/s)'
        ),
        
        # 启动移动控制节点
        Node(
            package='turn_on_dlrobot_robot',
            executable='movement_control_node',
            name='movement_control',
            output='log',
            parameters=[{
                'linear_speed': LaunchConfiguration('linear_speed'),
                'angular_speed': LaunchConfiguration('angular_speed'),
                'lateral_speed': LaunchConfiguration('lateral_speed'),
            }],
            remappings=[
                ('cmd_vel', 'cmd_vel'),
            ]
        )
    ]) 