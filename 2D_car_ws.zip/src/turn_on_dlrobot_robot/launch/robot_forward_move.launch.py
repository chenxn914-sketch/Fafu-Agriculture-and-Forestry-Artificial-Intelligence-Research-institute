from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    return LaunchDescription([
        # 启动底盘驱动（tank.launch.py）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'tank.launch.py'
                ])
            ]),
            launch_arguments={
                'akmcar': 'false'  # 使用普通模式，不使用Ackermann转向
            }.items()
        ),
        
        # 启动速度发布（forward_move.launch.py）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare('turn_on_dlrobot_robot'),
                    'launch',
                    'forward_move.launch.py'
                ])
            ])
        ),
    ]) 