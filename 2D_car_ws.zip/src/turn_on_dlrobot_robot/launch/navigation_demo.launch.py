import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # 路径获取
    pkg_turn_on = get_package_share_directory('turn_on_dlrobot_robot')
    pkg_nav2 = get_package_share_directory('nav2_bringup')
    pkg_rplidar = get_package_share_directory('rplidar_ros')
    default_map = os.path.join(pkg_turn_on, 'maps', 'my_map.yaml')
    default_params = os.path.join(pkg_turn_on, 'config', 'nav2_params.yaml')
    default_rviz = os.path.join(pkg_nav2, 'rviz', 'nav2_default_view.rviz')

    # 参数声明
    use_sim_time = LaunchConfiguration('use_sim_time')
    map_yaml = LaunchConfiguration('map')
    params_file = LaunchConfiguration('params_file')

    return LaunchDescription([
        # 声明参数
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation time if true'
        ),
        DeclareLaunchArgument(
            'map',
            default_value=default_map,
            description='Full path to map yaml file'
        ),
        DeclareLaunchArgument(
            'params_file',
            default_value=default_params,
            description='Full path to the ROS2 parameters file to use for all launched nodes'
        ),

        # 启动底盘驱动
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_turn_on, 'launch', 'tank.launch.py')
            ),
            launch_arguments={'akmcar': 'false'}.items()
        ),

        # 启动雷达
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_rplidar, 'launch', 'rplidar_a1_launch.py')
            ),
            launch_arguments={
                'serial_port': '/dev/ttyUSB0',
                'serial_baudrate': '115200',
                'frame_id': 'laser',
                'inverted': 'false',
                'angle_compensate': 'true'
            }.items()
        ),

        # 静态TF：base_footprint -> base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='basefootprint_to_baselink',
            arguments=['0', '0', '0', '0', '0', '0', 'base_footprint', 'base_link'],
            output='screen'
        ),
        # 静态TF：base_link -> laser
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='laser_to_base_link',
            arguments=['0', '0', '0.4', '0', '0', '0', 'base_link', 'laser'],
            output='screen'
        ),

        # 启动导航主流程（包含map_server、amcl、planner、controller、bt_navigator、lifecycle_manager等）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_nav2, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'map': map_yaml,
                'use_sim_time': use_sim_time,
                'params_file': params_file
            }.items()
        ),

        # 启动RViz
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', default_rviz],
            parameters=[{'use_sim_time': use_sim_time}],
            output='screen'
        ),
    ]) 