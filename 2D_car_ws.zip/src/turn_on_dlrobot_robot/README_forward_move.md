# 履带车向前移动控制说明

## 功能描述
通过启动相应的launch文件，可以让履带车机器人以 **0.05 m/s** 的速度向前移动，无转动。

## 文件说明

### 1. `src/forward_move_node.cpp`
- **作用**: 发布速度指令的C++节点
- **功能**: 持续发布 `/cmd_vel` 话题，消息内容为：
  - 线速度: `linear.x = 0.05 m/s` (向前)
  - 角速度: `angular.z = 0.0 rad/s` (无转动)

### 2. `launch/forward_move.launch.py`
- **作用**: 只启动速度发布节点
- **包含节点**:
  - `forward_move_node`: 速度发布节点

### 3. `launch/robot_forward_move.launch.py` (推荐)
- **作用**: 组合启动文件，同时启动底盘驱动和速度发布
- **包含功能**:
  - 底盘驱动节点（来自tank.launch.py）
  - 速度发布节点（来自forward_move.launch.py）

## 使用方法

### 方法一：模块化启动（推荐）
```bash
# 1. 编译包
colcon build --packages-select turn_on_dlrobot_robot
source install/setup.bash

# 2. 启动底盘驱动
ros2 launch turn_on_dlrobot_robot tank.launch.py

# 3. 在另一个终端启动速度发布
ros2 launch turn_on_dlrobot_robot forward_move.launch.py
```

### 方法二：一键启动
```bash
# 1. 编译包
colcon build --packages-select turn_on_dlrobot_robot
source install/setup.bash

# 2. 一键启动（推荐）
ros2 launch turn_on_dlrobot_robot robot_forward_move.launch.py
```

### 方法三：手动控制
```bash
# 1. 启动底盘驱动
ros2 launch turn_on_dlrobot_robot tank.launch.py

# 2. 手动发布速度指令
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.05, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

## 参数说明

### 速度参数
- **线速度**: 0.05 m/s (可在 `forward_move_node.cpp` 中修改 `msg.linear.x` 值)
- **角速度**: 0.0 rad/s (无转动)

### 串口参数
- **设备**: `/dev/ttyACM0`
- **波特率**: 115200
- **坐标系**: `base_footprint` (机器人坐标系)

## 模块化优势

### 1. **功能分离**
- `tank.launch.py`: 专门负责底盘驱动
- `forward_move.launch.py`: 专门负责速度发布

### 2. **灵活组合**
- 可以单独启动底盘驱动进行调试
- 可以单独启动速度发布进行测试
- 可以组合使用实现完整功能

### 3. **易于维护**
- 每个launch文件职责单一
- 便于独立测试和调试
- 便于扩展新功能

## 注意事项

1. **串口权限**: 确保当前用户有串口设备访问权限
2. **硬件连接**: 确保串口线正确连接到下位机
3. **安全**: 启动前确保机器人周围环境安全
4. **修改速度**: 如需调整速度，修改 `src/forward_move_node.cpp` 中的 `msg.linear.x` 值

## 故障排除

### 1. 找不到launch文件
```bash
# 检查包是否正确安装
ros2 pkg list | grep turn_on_dlrobot_robot
```

### 2. 串口连接失败
```bash
# 检查串口设备是否存在
ls /dev/ttyACM*

# 检查串口权限
ls -l /dev/ttyACM0
```

### 3. 机器人不移动
```bash
# 检查话题是否正常发布
ros2 topic echo /cmd_vel

# 检查底盘节点状态
ros2 node list
ros2 node info /dlrobot_robot_node
```

### 4. 模块化调试
```bash
# 单独测试底盘驱动
ros2 launch turn_on_dlrobot_robot tank.launch.py

# 单独测试速度发布
ros2 launch turn_on_dlrobot_robot forward_move.launch.py

# 检查话题连接
ros2 topic info /cmd_vel
``` 