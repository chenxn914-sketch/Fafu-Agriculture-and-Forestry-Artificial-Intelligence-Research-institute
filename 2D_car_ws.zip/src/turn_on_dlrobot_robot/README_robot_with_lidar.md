# 履带车底盘驱动配合雷达使用说明

## 概述

本文档详细说明如何将履带车底盘驱动与激光雷达配合使用，实现SLAM建图和自主导航功能。

## 系统架构

### 硬件组成
- **履带车底盘**: 通过串口与ROS2节点通信
- **激光雷达**: RPLidar系列（A1/A2/A3/S2/C1等）
- **IMU传感器**: 集成在底盘中的MPU6050/MPU9250
- **串口设备**: 
  - 底盘控制器: `/dev/ttyACM0` 或 `/dev/ttyCH343USB0`
  - 激光雷达: `/dev/ttyUSB0` 或其他USB串口

### 软件架构
```
底盘驱动节点 (dlrobot_robot_node)
├── 发布里程计数据 (/odom_combined)
├── 发布IMU数据 (/mobile_base/sensors/imu_data)
├── 发布电压数据 (/PowerVoltage)
├── 订阅速度指令 (/cmd_vel)
└── 发布TF变换 (odom_combined -> base_footprint)

激光雷达节点 (rplidar_node)
├── 发布激光扫描数据 (/scan)
└── 发布TF变换 (laser -> base_footprint)

SLAM/导航节点
├── gmapping (建图)
├── amcl (定位)
├── nav2_controller (路径跟踪)
├── nav2_planner (路径规划)
└── nav2_bt_navigator (行为树导航)
```

## 坐标系说明

### TF变换树
```
map (地图坐标系)
└── odom_combined (里程计坐标系)
    └── base_footprint (机器人底盘坐标系)
        ├── base_link (机器人本体坐标系)
        │   └── gyro_link (IMU坐标系)
        └── laser (激光雷达坐标系)
```

### 坐标系参数
- **base_footprint**: 机器人底盘中心，地面高度
- **base_link**: 机器人本体中心，底盘上方0.1m
- **gyro_link**: IMU位置，base_link上方0.05m
- **laser**: 激光雷达位置，base_footprint上方0.5m

## 使用方法

### 1. 基础配置

#### 1.1 设置串口权限
```bash
# 运行udev脚本设置串口权限
sudo bash dlrobot_udev.sh

# 或者手动设置
sudo chmod 666 /dev/ttyACM0
sudo chmod 666 /dev/ttyUSB0
```

#### 1.2 检查串口设备
```bash
# 查看串口设备
ls -l /dev/ttyACM*
ls -l /dev/ttyUSB*

# 测试串口连接
sudo apt install minicom
minicom -D /dev/ttyACM0 -b 115200
minicom -D /dev/ttyUSB0 -b 115200
```

### 2. 启动方式

#### 2.1 基础启动（底盘+雷达）
```bash
# 编译包
colcon build --packages-select turn_on_dlrobot_robot rplidar_ros
source install/setup.bash

# 启动底盘和雷达
ros2 launch turn_on_dlrobot_robot robot_with_lidar.launch.py
```

#### 2.2 SLAM建图
```bash
# 启动SLAM建图
ros2 launch turn_on_dlrobot_robot robot_slam.launch.py

# 使用键盘控制机器人移动进行建图
ros2 launch turn_on_dlrobot_robot keyboard_control.launch.py
```

#### 2.3 自主导航
```bash
# 启动导航（需要先有地图文件）
ros2 launch turn_on_dlrobot_robot robot_navigation.launch.py map_file:=/path/to/map.yaml
```

### 3. 参数配置

#### 3.1 串口参数
```bash
# 指定不同的串口设备
ros2 launch turn_on_dlrobot_robot robot_with_lidar.launch.py \
    robot_serial_port:=/dev/ttyCH343USB0 \
    serial_port:=/dev/ttyUSB1
```

#### 3.2 雷达类型
```bash
# 指定雷达类型
ros2 launch turn_on_dlrobot_robot robot_with_lidar.launch.py \
    lidar_type:=a1  # 可选: a1, a2, a3, s2, c1
```

#### 3.3 机器人模式
```bash
# 使用Ackermann转向模式
ros2 launch turn_on_dlrobot_robot robot_with_lidar.launch.py \
    akmcar:=true
```

### 4. 话题监控

#### 4.1 检查话题状态
```bash
# 查看所有话题
ros2 topic list

# 查看话题信息
ros2 topic info /odom_combined
ros2 topic info /scan
ros2 topic info /cmd_vel

# 实时查看话题数据
ros2 topic echo /odom_combined
ros2 topic echo /scan
```

#### 4.2 检查TF变换
```bash
# 查看TF变换树
ros2 run tf2_tools view_frames

# 查看特定变换
ros2 run tf2_ros tf2_echo base_footprint laser
```

### 5. 数据记录与回放

#### 5.1 记录数据
```bash
# 记录所有话题数据
ros2 bag record -a

# 记录特定话题
ros2 bag record /odom_combined /scan /cmd_vel /mobile_base/sensors/imu_data
```

#### 5.2 回放数据
```bash
# 回放数据
ros2 bag play <bag_file_name>
```

## 故障排除

### 1. 串口连接问题

#### 问题：无法打开串口
```bash
# 检查串口设备是否存在
ls -l /dev/ttyACM*

# 检查串口权限
ls -l /dev/ttyACM0

# 重新设置权限
sudo chmod 666 /dev/ttyACM0
```

#### 问题：串口被占用
```bash
# 查看串口占用情况
lsof | grep ttyACM

# 杀死占用进程
sudo kill -9 <PID>
```

### 2. 雷达数据问题

#### 问题：雷达无数据
```bash
# 检查雷达话题
ros2 topic echo /scan

# 检查雷达节点状态
ros2 node list
ros2 node info /rplidar_node

# 重启雷达节点
ros2 launch rplidar_ros lidar.launch.py
```

#### 问题：雷达数据异常
```bash
# 检查雷达参数
ros2 param list /rplidar_node

# 调整雷达参数
ros2 param set /rplidar_node serial_port /dev/ttyUSB0
ros2 param set /rplidar_node serial_baudrate 115200
```

### 3. 里程计问题

#### 问题：里程计数据异常
```bash
# 检查里程计话题
ros2 topic echo /odom_combined

# 检查底盘节点状态
ros2 node list
ros2 node info /dlrobot_robot_node

# 检查串口通信
ros2 topic echo /PowerVoltage
```

#### 问题：TF变换错误
```bash
# 检查TF变换
ros2 run tf2_ros tf2_echo odom_combined base_footprint

# 查看TF变换树
ros2 run tf2_tools view_frames
```

### 4. SLAM/导航问题

#### 问题：建图效果差
```bash
# 调整gmapping参数
ros2 param set /slam_gmapping maxUrange 6.0
ros2 param set /slam_gmapping maxRange 8.0
ros2 param set /slam_gmapping particles 30
```

#### 问题：定位不准确
```bash
# 调整amcl参数
ros2 param set /amcl max_particles 2000
ros2 param set /amcl min_particles 500
ros2 param set /amcl alpha1 0.2
```

## 性能优化

### 1. 系统性能
```bash
# 监控CPU和内存使用
htop

# 监控磁盘I/O
iotop

# 监控网络
iftop
```

### 2. ROS2性能
```bash
# 查看节点性能
ros2 node list
ros2 node info <node_name>

# 查看话题频率
ros2 topic hz /scan
ros2 topic hz /odom_combined
```

### 3. 参数调优

#### 里程计参数
- 提高里程计更新频率
- 调整协方差矩阵
- 优化积分算法

#### 雷达参数
- 调整扫描频率
- 优化角度补偿
- 设置合适的测量范围

#### SLAM参数
- 调整粒子数量
- 优化地图更新频率
- 设置合适的运动模型参数

## 扩展功能

### 1. 多传感器融合
- 添加相机传感器
- 集成GPS定位
- 使用多激光雷达

### 2. 高级导航
- 动态避障
- 路径优化
- 多目标点导航

### 3. 远程控制
- Web界面控制
- 移动端APP
- 远程监控

## 注意事项

1. **安全第一**: 确保机器人周围环境安全，避免碰撞
2. **电池管理**: 监控电池电压，及时充电
3. **数据备份**: 定期备份地图和配置文件
4. **系统更新**: 保持ROS2和依赖包的最新版本
5. **硬件维护**: 定期检查串口连接和传感器状态

## 技术支持

如遇到问题，请检查：
1. 串口连接是否正常
2. 权限设置是否正确
3. 话题是否正常发布
4. TF变换是否正确
5. 参数配置是否合理

更多详细信息请参考：
- [ROS2官方文档](https://docs.ros.org/en/humble/)
- [Nav2文档](https://navigation.ros.org/)
- [RPLidar文档](https://www.slamtec.com/en/Support#rplidar-a-series) 