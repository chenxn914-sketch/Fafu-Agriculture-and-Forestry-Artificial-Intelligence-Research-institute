# 履带车移动控制说明

## 功能描述
通过启动相应的launch文件，可以使用键盘控制履带车机器人进行前后左右移动，支持前进、后退、左转、右转、左移、右移、停止等功能。

## 文件说明

### 1. `src/movement_control_node.cpp`
- **作用**: 移动控制C++节点
- **功能**: 
  - 支持键盘实时控制
  - 可配置的速度参数
  - 支持全向移动（如果硬件支持）
  - 安全停止机制

### 2. `launch/movement_control.launch.py`
- **作用**: 只启动移动控制节点
- **包含节点**:
  - `movement_control_node`: 移动控制节点

### 3. `launch/robot_movement_control.launch.py` (推荐)
- **作用**: 组合启动文件，同时启动底盘驱动和移动控制
- **包含功能**:
  - 底盘驱动节点（来自tank.launch.py）
  - 移动控制节点（来自movement_control.launch.py）

## 控制按键

| 按键 | 功能 | 说明 |
|------|------|------|
| W | 前进 | 向前直线移动 |
| S | 后退 | 向后直线移动 |
| A | 左转 | 原地左转 |
| D | 右转 | 原地右转 |
| Q | 左移 | 向左平移（如果支持全向移动） |
| E | 右移 | 向右平移（如果支持全向移动） |
| 空格 | 停止 | 立即停止所有运动 |
| X | 退出 | 停止并退出程序 |

## 使用方法

### 方法一：模块化启动
```bash
# 1. 编译包
colcon build --packages-select turn_on_dlrobot_robot
source install/setup.bash

# 2. 启动底盘驱动
ros2 launch turn_on_dlrobot_robot tank.launch.py

# 3. 在另一个终端启动移动控制
ros2 launch turn_on_dlrobot_robot movement_control.launch.py
```

### 方法二：一键启动（推荐）
```bash
# 1. 编译包
colcon build --packages-select turn_on_dlrobot_robot
source install/setup.bash

# 2. 一键启动
ros2 launch turn_on_dlrobot_robot robot_movement_control.launch.py
```

### 方法三：自定义速度参数
```bash
# 启动时指定速度参数
ros2 launch turn_on_dlrobot_robot robot_movement_control.launch.py \
    linear_speed:=0.15 \
    angular_speed:=0.8 \
    lateral_speed:=0.08
```

## 参数说明

### 速度参数
- **linear_speed**: 线速度，默认0.1 m/s
- **angular_speed**: 角速度，默认0.5 rad/s  
- **lateral_speed**: 侧向速度，默认0.05 m/s

### 底盘模式参数
- **akmcar**: 是否使用Ackermann转向模式，默认false

## 功能特点

### 1. **实时响应**
- 50ms检测周期，确保按键响应及时
- 支持大小写字母输入

### 2. **安全机制**
- 程序启动时自动发送停止命令
- 程序退出时自动停止机器人
- 空格键可随时停止运动

### 3. **参数化配置**
- 支持通过launch文件参数调整速度
- 支持通过ROS2参数系统动态配置

### 4. **状态反馈**
- 实时显示当前运动状态
- 显示配置的速度参数
- 提供详细的操作提示

## 硬件兼容性

### 履带车底盘
- 支持前进、后退、左转、右转
- 左移、右移功能需要全向底盘支持

### 串口通信
- 设备: `/dev/ttyACM0` (可通过参数修改)
- 波特率: 115200
- 通信协议: 自定义二进制协议

## 故障排除

### 1. 按键无响应
```bash
# 检查终端设置
echo $TERM
# 确保在支持raw模式的终端中运行
```

### 2. 机器人不移动
```bash
# 检查话题连接
ros2 topic echo /cmd_vel

# 检查底盘节点状态
ros2 node list
ros2 node info /dlrobot_robot_node
```

### 3. 串口连接失败
```bash
# 检查串口设备
ls /dev/ttyACM*

# 检查串口权限
ls -l /dev/ttyACM0

# 运行udev脚本设置权限
sudo bash dlrobot_udev.sh
```

### 4. 速度过快或过慢
```bash
# 调整速度参数
ros2 launch turn_on_dlrobot_robot robot_movement_control.launch.py \
    linear_speed:=0.05 \
    angular_speed:=0.3
```

## 开发扩展

### 添加新的控制按键
在 `movement_control_node.cpp` 的 `checkKey()` 函数中添加新的case分支：

```cpp
case 'z':
case 'Z':
    // 新功能
    break;
```

### 修改速度计算
可以添加速度渐变、加速度限制等功能：

```cpp
// 在类中添加速度渐变功能
void smoothVelocityChange(double target_linear_x, double target_angular_z);
```

### 添加遥控器支持
可以扩展支持游戏手柄或其他输入设备：

```cpp
// 添加游戏手柄订阅
auto joy_sub = create_subscription<sensor_msgs::msg::Joy>(
    "joy", 10, std::bind(&MovementControl::joyCallback, this, _1));
```

## 注意事项

1. **安全第一**: 确保机器人周围环境安全
2. **速度适中**: 根据环境调整合适的速度参数
3. **电池电量**: 注意监控电池电压
4. **紧急停止**: 记住空格键可以立即停止
5. **权限设置**: 确保串口设备有正确的访问权限 