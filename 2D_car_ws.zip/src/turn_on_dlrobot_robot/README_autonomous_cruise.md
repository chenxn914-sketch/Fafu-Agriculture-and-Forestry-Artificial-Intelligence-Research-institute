# 履带车自动巡航使用指南

## 概述
本指南说明如何使用Nav2导航栈实现履带车的自动巡航功能。

## 功能特点
- ✅ 基于构建的地图进行导航
- ✅ 自动路径规划
- ✅ 自动避障
- ✅ 多点巡航
- ✅ 循环巡航

## 系统要求

### 1. 安装Nav2导航栈
```bash
# 安装Nav2核心包
sudo apt install ros-humble-nav2-bringup ros-humble-nav2-core ros-humble-nav2-controller ros-humble-nav2-planner ros-humble-nav2-behavior-tree ros-humble-nav2-msgs ros-humble-nav2-amcl ros-humble-nav2-map-server

# 或者安装所有Nav2包
sudo apt install ros-humble-nav2-*
```

### 2. 准备地图文件
```bash
# 保存当前地图（如果还没有）
ros2 run nav2_map_server map_saver_cli -f ~/my_map
```

## 使用方法

### 1. 启动导航系统
```bash
# 编译项目
cd "ROS2底盘驱动包"
colcon build
source install/setup.bash

# 设置串口权限
sudo chmod 666 /dev/ttyCH343USB0  # 底盘
sudo chmod 666 /dev/ttyUSB0       # 雷达

# 启动导航系统
ros2 launch turn_on_dlrobot_robot navigation_demo.launch.py map_file:=~/my_map.yaml
```

### 2. 设置初始位姿
在RViz中：
1. 点击 "2D Pose Estimate" 按钮
2. 在地图上点击并拖拽设置机器人的初始位置和方向
3. 确保位姿准确，这对导航精度很重要

### 3. 手动导航测试
```bash
# 使用RViz进行手动导航测试
# 在RViz中点击 "2D Nav Goal" 按钮
# 在地图上点击目标位置
```

### 4. 启动自动巡航
```bash
# 启动巡航控制器
ros2 run turn_on_dlrobot_robot set_cruise_points.py
```

## 巡航点配置

### 默认巡航点
脚本中预设了4个巡航点：
- 点1：(1.0, 0.0, 0.0) - 前方1米
- 点2：(1.0, 1.0, 1.57) - 右前方1米，面向右
- 点3：(0.0, 1.0, 3.14) - 右侧1米，面向后
- 点4：(0.0, 0.0, 0.0) - 回到起点

### 自定义巡航点
修改 `scripts/set_cruise_points.py` 中的 `cruise_points` 列表：

```python
self.cruise_points = [
    (x1, y1, theta1),  # 点1
    (x2, y2, theta2),  # 点2
    (x3, y3, theta3),  # 点3
    # 添加更多点...
]
```

## 导航参数调整

### 控制器参数
在 `navigation_demo.launch.py` 中可以调整：
- `desired_linear_vel`: 期望线速度 (默认0.2 m/s)
- `lookahead_dist`: 前瞻距离 (默认0.3 m)
- `min_approach_linear_velocity`: 接近目标时的最小速度

### AMCL定位参数
- `min_particles`: 最小粒子数 (默认500)
- `max_particles`: 最大粒子数 (默认2000)
- `alpha1-5`: 里程计噪声参数

### 路径规划参数
- `tolerance`: 目标容差 (默认0.5 m)
- `allow_unknown`: 是否允许未知区域 (默认True)

## 故障排除

### 1. 导航服务器未启动
```bash
# 检查导航节点状态
ros2 node list | grep nav2

# 检查导航话题
ros2 topic list | grep nav2
```

### 2. 定位不准确
```bash
# 重新设置初始位姿
# 在RViz中使用 "2D Pose Estimate" 重新设置

# 检查AMCL状态
ros2 topic echo /amcl_pose
```

### 3. 路径规划失败
```bash
# 检查地图数据
ros2 topic echo /map

# 检查激光数据
ros2 topic echo /scan

# 检查代价地图
ros2 topic echo /local_costmap/costmap
ros2 topic echo /global_costmap/costmap
```

### 4. 机器人卡住
```bash
# 检查恢复行为
ros2 service call /recoveries_server/trigger_behavior std_srvs/srv/Trigger

# 手动控制机器人移动
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

## 高级功能

### 1. 动态添加巡航点
```python
# 在巡航控制器中添加点
cruise_controller.add_cruise_point(x, y, theta)
```

### 2. 自定义巡航路径
```python
# 设置自定义巡航点列表
points = [(x1, y1, theta1), (x2, y2, theta2), ...]
cruise_controller.set_cruise_points(points)
```

### 3. 监控巡航状态
```bash
# 查看导航状态
ros2 topic echo /navigation_status

# 查看当前目标
ros2 topic echo /goal_pose
```

## 安全注意事项

1. **环境安全**: 确保巡航区域安全，避免碰撞
2. **速度控制**: 根据环境调整巡航速度
3. **紧急停止**: 准备紧急停止机制
4. **监控**: 持续监控机器人状态
5. **电池管理**: 注意电池电量，及时充电

## 性能优化

### 1. 提高导航精度
- 调整AMCL参数
- 优化地图质量
- 校准传感器

### 2. 提高导航效率
- 优化路径规划算法
- 调整控制器参数
- 减少不必要的停止

### 3. 系统稳定性
- 监控系统资源使用
- 定期检查传感器状态
- 备份重要配置

## 扩展功能

### 1. 多机器人巡航
- 使用命名空间隔离
- 协调路径规划
- 避免碰撞

### 2. 远程监控
- Web界面控制
- 移动端APP
- 远程状态监控

### 3. 智能巡航
- 基于时间的巡航
- 基于事件的巡航
- 自适应路径规划 