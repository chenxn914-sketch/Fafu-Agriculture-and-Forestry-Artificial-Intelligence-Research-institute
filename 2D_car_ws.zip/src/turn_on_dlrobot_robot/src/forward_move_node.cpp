#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <chrono>

using namespace std::chrono_literals;

class ForwardMoveNode : public rclcpp::Node
{
public:
    ForwardMoveNode() : Node("forward_move_node")
    {
        // 创建发布者，发布到 /cmd_vel 话题
        publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
        
        // 创建定时器，每100ms发布一次速度指令
        timer_ = this->create_wall_timer(100ms, std::bind(&ForwardMoveNode::publish_velocity, this));
        
        RCLCPP_INFO(this->get_logger(), "Forward move node started - moving at 0.05 m/s");
    }

private:
    void publish_velocity()
    {
        // 创建速度消息
        auto msg = geometry_msgs::msg::Twist();
        
        // 设置线速度：x方向0.05 m/s（向前），y和z方向为0
        msg.linear.x = 0.05;
        msg.linear.y = 0.0;
        msg.linear.z = 0.0;
        
        // 设置角速度：所有方向都为0（无转动）
        msg.angular.x = 0.0;
        msg.angular.y = 0.0;
        msg.angular.z = 0.0;
        
        // 发布消息
        publisher_->publish(msg);
        RCLCPP_DEBUG(this->get_logger(), "Published velocity: linear.x=0.05, angular.z=0.0");
    }
    
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    
    // 创建节点
    auto node = std::make_shared<ForwardMoveNode>();
    
    try {
        // 运行节点
        rclcpp::spin(node);
    } catch (const std::exception& e) {
        RCLCPP_ERROR(node->get_logger(), "Exception in forward move node: %s", e.what());
    }
    
    // 清理
    rclcpp::shutdown();
    return 0;
} 