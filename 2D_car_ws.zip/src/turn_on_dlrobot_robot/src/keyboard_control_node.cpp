#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <map>

class KeyboardControl : public rclcpp::Node
{
public:
    KeyboardControl()
    : Node("keyboard_control_node")
    {
        publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
        RCLCPP_INFO(this->get_logger(), "Keyboard control started. Use W/A/S/D keys to move, Q to quit.");

        // 终端设置：禁用缓冲和回显
        tcgetattr(STDIN_FILENO, &old_settings_);
        new_settings_ = old_settings_;
        new_settings_.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &new_settings_);

        timer_ = this->create_wall_timer(std::chrono::milliseconds(100),
                                         std::bind(&KeyboardControl::checkKey, this));
    }

    ~KeyboardControl()
    {
        tcsetattr(STDIN_FILENO, TCSANOW, &old_settings_);
    }

private:
    void checkKey()
    {
        char c;
        if (read(STDIN_FILENO, &c, 1) < 0)
            return;

        auto msg = geometry_msgs::msg::Twist(); 

        switch (c)
        {
        case 'w':
            msg.linear.x = 0.05;
            break;
        case 's':
            msg.linear.x = -0.05;
            break;
        case 'a':
            msg.angular.z = 0.05;
            break;
        case 'd':
            msg.angular.z = -0.05;
            break;
        case ' ':
            msg.linear.x = 0.0;
            msg.angular.z = 0.0;
            break;
        case 'q':
            rclcpp::shutdown();
            return;
        default:
            return;
        }

        publisher_->publish(msg);
    }

    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    struct termios old_settings_, new_settings_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<KeyboardControl>());
    rclcpp::shutdown();
    return 0;
}
