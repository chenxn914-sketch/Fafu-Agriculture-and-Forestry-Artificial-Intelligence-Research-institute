#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <map>
#include <string>

class MovementControl : public rclcpp::Node
{
public:
    MovementControl()
    : Node("movement_control_node")
    {
        // 声明参数
        this->declare_parameter("linear_speed", 0.1);
        this->declare_parameter("angular_speed", 0.5);
        this->declare_parameter("lateral_speed", 0.05);
        
        // 获取参数
        this->get_parameter("linear_speed", linear_speed_);
        this->get_parameter("angular_speed", angular_speed_);
        this->get_parameter("lateral_speed", lateral_speed_);
        
        publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
        
        RCLCPP_INFO(this->get_logger(), "Movement control started!");
        RCLCPP_INFO(this->get_logger(), "Control keys:");
        RCLCPP_INFO(this->get_logger(), "  W - Forward");
        RCLCPP_INFO(this->get_logger(), "  S - Backward");
        RCLCPP_INFO(this->get_logger(), "  A - Turn Left");
        RCLCPP_INFO(this->get_logger(), "  D - Turn Right");
        RCLCPP_INFO(this->get_logger(), "  Q - Move Left (if supported)");
        RCLCPP_INFO(this->get_logger(), "  E - Move Right (if supported)");
        RCLCPP_INFO(this->get_logger(), "  Space - Stop");
        RCLCPP_INFO(this->get_logger(), "  X - Quit");
        RCLCPP_INFO(this->get_logger(), "Speed settings: Linear=%.2f, Angular=%.2f, Lateral=%.2f", 
                   linear_speed_, angular_speed_, lateral_speed_);

        // 检查stdin是否可用
        if (isatty(STDIN_FILENO)) {
            // 终端设置：禁用缓冲和回显
            if (tcgetattr(STDIN_FILENO, &old_settings_) == 0) {
                new_settings_ = old_settings_;
                new_settings_.c_lflag &= ~(ICANON | ECHO);
                tcsetattr(STDIN_FILENO, TCSANOW, &new_settings_);
                RCLCPP_INFO(this->get_logger(), "Terminal configured for keyboard input");
                keyboard_available_ = true;
            } else {
                RCLCPP_WARN(this->get_logger(), "Failed to configure terminal, keyboard input may not work");
                keyboard_available_ = false;
            }
        } else {
            RCLCPP_WARN(this->get_logger(), "STDIN is not a terminal, keyboard input disabled");
            keyboard_available_ = false;
        }

        // 创建定时器，每100ms检查一次按键
        timer_ = this->create_wall_timer(std::chrono::milliseconds(100),
                                         std::bind(&MovementControl::checkKey, this));
        
        // 初始化速度消息
        current_velocity_ = geometry_msgs::msg::Twist();
        current_velocity_.linear.x = 0.0;
        current_velocity_.linear.y = 0.0;
        current_velocity_.linear.z = 0.0;
        current_velocity_.angular.x = 0.0;
        current_velocity_.angular.y = 0.0;
        current_velocity_.angular.z = 0.0;
        
        // 发布初始停止命令
        publisher_->publish(current_velocity_);
    }

    ~MovementControl()
    {
        // 停止机器人
        stopRobot();
        // 恢复终端设置
        if (keyboard_available_ && tcsetattr(STDIN_FILENO, TCSANOW, &old_settings_) == 0) {
            RCLCPP_INFO(this->get_logger(), "Terminal settings restored");
        }
        RCLCPP_INFO(this->get_logger(), "Movement control stopped.");
    }

private:
    void checkKey()
    {
        if (!keyboard_available_) {
            return;
        }
        
        char c;
        if (read(STDIN_FILENO, &c, 1) < 0)
            return;

        bool velocity_changed = false;

        switch (c)
        {
        case 'w':
        case 'W':
            // 前进
            current_velocity_.linear.x = linear_speed_;
            current_velocity_.linear.y = 0.0;
            current_velocity_.angular.z = 0.0;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Moving FORWARD");
            break;
            
        case 's':
        case 'S':
            // 后退
            current_velocity_.linear.x = -linear_speed_;
            current_velocity_.linear.y = 0.0;
            current_velocity_.angular.z = 0.0;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Moving BACKWARD");
            break;
            
        case 'a':
        case 'A':
            // 左转
            current_velocity_.linear.x = 0.0;
            current_velocity_.linear.y = 0.0;
            current_velocity_.angular.z = angular_speed_;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Turning LEFT");
            break;
            
        case 'd':
        case 'D':
            // 右转
            current_velocity_.linear.x = 0.0;
            current_velocity_.linear.y = 0.0;
            current_velocity_.angular.z = -angular_speed_;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Turning RIGHT");
            break;
            
        case 'q':
        case 'Q':
            // 左移（如果支持全向移动）
            current_velocity_.linear.x = 0.0;
            current_velocity_.linear.y = lateral_speed_;
            current_velocity_.angular.z = 0.0;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Moving LEFT");
            break;
            
        case 'e':
        case 'E':
            // 右移（如果支持全向移动）
            current_velocity_.linear.x = 0.0;
            current_velocity_.linear.y = -lateral_speed_;
            current_velocity_.angular.z = 0.0;
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "Moving RIGHT");
            break;
            
        case ' ':
            // 停止
            stopRobot();
            velocity_changed = true;
            RCLCPP_INFO(this->get_logger(), "STOPPED");
            break;
            
        case 'x':
        case 'X':
            // 退出
            stopRobot();
            RCLCPP_INFO(this->get_logger(), "Quitting...");
            rclcpp::shutdown();
            return;
            
        default:
            return;
        }

        if (velocity_changed)
        {
            publisher_->publish(current_velocity_);
        }
    }
    
    void stopRobot()
    {
        current_velocity_.linear.x = 0.0;
        current_velocity_.linear.y = 0.0;
        current_velocity_.linear.z = 0.0;
        current_velocity_.angular.x = 0.0;
        current_velocity_.angular.y = 0.0;
        current_velocity_.angular.z = 0.0;
        publisher_->publish(current_velocity_);
    }

    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    struct termios old_settings_, new_settings_;
    
    // 速度参数
    double linear_speed_;
    double angular_speed_;
    double lateral_speed_;
    
    // 当前速度状态
    geometry_msgs::msg::Twist current_velocity_;
    
    // 键盘可用标志
    bool keyboard_available_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    
    try {
        auto node = std::make_shared<MovementControl>();
        rclcpp::spin(node);
    } catch (const std::exception& e) {
        RCLCPP_ERROR(rclcpp::get_logger("movement_control"), "Exception in movement control node: %s", e.what());
    }
    
    rclcpp::shutdown();
    return 0;
} 