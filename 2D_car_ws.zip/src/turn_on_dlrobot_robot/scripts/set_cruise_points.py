#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
import time

class CruiseController(Node):
    def __init__(self):
        super().__init__('cruise_controller')
        
        # 创建导航动作客户端
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # 巡航点列表 (x, y, theta)
        self.cruise_points = [
            (1.0, 0.0, 0.0),    # 点1：前方1米
            (1.0, 1.0, 1.57),   # 点2：右前方1米，面向右
            (0.0, 1.0, 3.14),   # 点3：右侧1米，面向后
            (0.0, 0.0, 0.0),    # 点4：回到起点
        ]
        
        self.current_point_index = 0
        self.is_navigating = False
        
        self.get_logger().info("巡航控制器已启动")
        self.get_logger().info(f"设置了 {len(self.cruise_points)} 个巡航点")
        
    def start_cruise(self):
        """开始巡航"""
        self.get_logger().info("开始巡航...")
        self.navigate_to_next_point()
        
    def navigate_to_next_point(self):
        """导航到下一个点"""
        if self.current_point_index >= len(self.cruise_points):
            self.get_logger().info("巡航完成，重新开始")
            self.current_point_index = 0
            
        x, y, theta = self.cruise_points[self.current_point_index]
        
        # 创建目标位姿
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        goal_msg.pose.pose.position.z = 0.0
        
        # 设置方向（四元数）
        import math
        goal_msg.pose.pose.orientation.x = 0.0
        goal_msg.pose.pose.orientation.y = 0.0
        goal_msg.pose.pose.orientation.z = math.sin(theta / 2.0)
        goal_msg.pose.pose.orientation.w = math.cos(theta / 2.0)
        
        self.get_logger().info(f"导航到点 {self.current_point_index + 1}: ({x}, {y}, {theta})")
        
        # 发送导航目标
        self._action_client.send_goal_async(goal_msg, self.goal_response_callback)
        
    def goal_response_callback(self, future):
        """目标响应回调"""
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('导航目标被拒绝')
            return
            
        self.get_logger().info('导航目标被接受，开始导航')
        self.is_navigating = True
        
        # 获取结果
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)
        
    def get_result_callback(self, future):
        """结果回调"""
        result = future.result().result
        self.get_logger().info(f'导航完成，结果: {result}')
        
        self.is_navigating = False
        self.current_point_index += 1
        
        # 等待一段时间后导航到下一个点
        time.sleep(2.0)
        self.navigate_to_next_point()
        
    def add_cruise_point(self, x, y, theta):
        """添加巡航点"""
        self.cruise_points.append((x, y, theta))
        self.get_logger().info(f"添加巡航点: ({x}, {y}, {theta})")
        
    def clear_cruise_points(self):
        """清空巡航点"""
        self.cruise_points.clear()
        self.get_logger().info("清空所有巡航点")
        
    def set_cruise_points(self, points):
        """设置巡航点列表"""
        self.cruise_points = points
        self.get_logger().info(f"设置 {len(points)} 个巡航点")

def main(args=None):
    rclpy.init(args=args)
    
    cruise_controller = CruiseController()
    
    try:
        # 等待导航服务器启动
        cruise_controller.get_logger().info("等待导航服务器...")
        cruise_controller._action_client.wait_for_server()
        
        # 开始巡航
        cruise_controller.start_cruise()
        
        # 运行节点
        rclpy.spin(cruise_controller)
        
    except KeyboardInterrupt:
        cruise_controller.get_logger().info("巡航被用户中断")
    except Exception as e:
        cruise_controller.get_logger().error(f"巡航出错: {e}")
    finally:
        cruise_controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main() 