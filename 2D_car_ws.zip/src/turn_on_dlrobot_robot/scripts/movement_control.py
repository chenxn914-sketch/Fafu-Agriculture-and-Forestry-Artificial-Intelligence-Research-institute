#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from pynput import keyboard
import threading
import time

class MovementControl(Node):
    def __init__(self):
        super().__init__('movement_control_node')
        
        # 声明参数
        self.declare_parameter('linear_speed', 0.1)
        self.declare_parameter('angular_speed', 0.5)
        self.declare_parameter('lateral_speed', 0.05)
        
        # 获取参数
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.lateral_speed = self.get_parameter('lateral_speed').value
        
        # 创建发布者
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # 当前速度状态
        self.current_velocity = Twist()
        self.current_velocity.linear.x = 0.0
        self.current_velocity.linear.y = 0.0
        self.current_velocity.linear.z = 0.0
        self.current_velocity.angular.x = 0.0
        self.current_velocity.angular.y = 0.0
        self.current_velocity.angular.z = 0.0
        
        # 键盘监听器
        self.listener = None
        self.running = True
        
        # 打印控制说明
        self.get_logger().info("Movement control started!")
        self.get_logger().info("Control keys:")
        self.get_logger().info("  W - Forward")
        self.get_logger().info("  S - Backward")
        self.get_logger().info("  A - Turn Left")
        self.get_logger().info("  D - Turn Right")
        self.get_logger().info("  Q - Move Left (if supported)")
        self.get_logger().info("  E - Move Right (if supported)")
        self.get_logger().info("  Space - Stop")
        self.get_logger().info("  X - Quit")
        self.get_logger().info(f"Speed settings: Linear={self.linear_speed:.2f}, Angular={self.angular_speed:.2f}, Lateral={self.lateral_speed:.2f}")
        
        # 发布初始停止命令
        self.publisher.publish(self.current_velocity)
        
        # 启动键盘监听
        self.start_keyboard_listener()
        
    def start_keyboard_listener(self):
        """启动键盘监听器"""
        try:
            self.listener = keyboard.Listener(
                on_press=self.on_key_press,
                on_release=self.on_key_release
            )
            self.listener.start()
            self.get_logger().info("Keyboard listener started")
        except Exception as e:
            self.get_logger().error(f"Failed to start keyboard listener: {e}")
    
    def on_key_press(self, key):
        """按键按下回调"""
        try:
            if hasattr(key, 'char') and key.char:
                char = key.char.lower()
                
                if char == 'w':
                    # 前进
                    self.current_velocity.linear.x = self.linear_speed
                    self.current_velocity.linear.y = 0.0
                    self.current_velocity.angular.z = 0.0
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Moving FORWARD")
                    
                elif char == 's':
                    # 后退
                    self.current_velocity.linear.x = -self.linear_speed
                    self.current_velocity.linear.y = 0.0
                    self.current_velocity.angular.z = 0.0
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Moving BACKWARD")
                    
                elif char == 'a':
                    # 左转
                    self.current_velocity.linear.x = 0.0
                    self.current_velocity.linear.y = 0.0
                    self.current_velocity.angular.z = self.angular_speed
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Turning LEFT")
                    
                elif char == 'd':
                    # 右转
                    self.current_velocity.linear.x = 0.0
                    self.current_velocity.linear.y = 0.0
                    self.current_velocity.angular.z = -self.angular_speed
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Turning RIGHT")
                    
                elif char == 'q':
                    # 左移
                    self.current_velocity.linear.x = 0.0
                    self.current_velocity.linear.y = self.lateral_speed
                    self.current_velocity.angular.z = 0.0
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Moving LEFT")
                    
                elif char == 'e':
                    # 右移
                    self.current_velocity.linear.x = 0.0
                    self.current_velocity.linear.y = -self.lateral_speed
                    self.current_velocity.angular.z = 0.0
                    self.publisher.publish(self.current_velocity)
                    self.get_logger().info("Moving RIGHT")
                    
                elif char == 'x':
                    # 退出
                    self.stop_robot()
                    self.get_logger().info("Quitting...")
                    self.running = False
                    rclpy.shutdown()
                    return False
                    
            elif key == keyboard.Key.space:
                # 停止
                self.stop_robot()
                self.get_logger().info("STOPPED")
                
        except Exception as e:
            self.get_logger().error(f"Error processing key press: {e}")
    
    def on_key_release(self, key):
        """按键释放回调"""
        # 可以在这里添加按键释放时的逻辑
        pass
    
    def stop_robot(self):
        """停止机器人"""
        self.current_velocity.linear.x = 0.0
        self.current_velocity.linear.y = 0.0
        self.current_velocity.linear.z = 0.0
        self.current_velocity.angular.x = 0.0
        self.current_velocity.angular.y = 0.0
        self.current_velocity.angular.z = 0.0
        self.publisher.publish(self.current_velocity)
    
    def cleanup(self):
        """清理资源"""
        if self.listener:
            self.listener.stop()
        self.stop_robot()

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = MovementControl()
        
        # 主循环
        while rclpy.ok() and node.running:
            rclpy.spin_once(node, timeout_sec=0.1)
            time.sleep(0.01)
            
    except KeyboardInterrupt:
        pass
    except Exception as e:
        node.get_logger().error(f"Exception in movement control node: {e}")
    finally:
        if 'node' in locals():
            node.cleanup()
        rclpy.shutdown()

if __name__ == '__main__':
    main() 