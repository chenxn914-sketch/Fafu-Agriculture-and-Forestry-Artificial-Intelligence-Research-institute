   import rclpy
   from rclpy.node import Node
   from geometry_msgs.msg import Twist
   import time

   rclpy.init()
   node = Node('test_pub')
   pub = node.create_publisher(Twist, 'cmd_vel', 10)
   msg = Twist()
   msg.linear.x = 0.5
   print("Publishing...")
   for _ in range(10):
       pub.publish(msg)
       time.sleep(0.1)
   rclpy.shutdown()