# 履带车ROS2驱动 - Gmapping SLAM 设置指南

## 概述
本指南说明如何配置履带车底盘驱动与A1激光雷达配合使用gmapping进行SLAM建图。

## TF树结构
```
map
└── odom
    └── base_footprint
        └── laser
```

## 坐标系说明
- `map`: 地图坐标系，由gmapping发布
- `odom`: 里程计坐标系，由底盘驱动发布
- `base_footprint`: 机器人底盘坐标系
- `laser`: 激光雷达坐标系

## 启动步骤

### 1. 设置串口权限
```bash
# 设置底盘串口权限
sudo chmod 666 /dev/ttyCH343USB0

# 设置雷达串口权限
sudo chmod 666 /dev/ttyUSB0
```

### 2. 启动gmapping演示
```bash
# 进入工作空间
cd ~/ros2_ws

# 编译
colcon build

# 设置环境变量
source install/setup.bash

# 启动gmapping演示
ros2 launch turn_on_dlrobot_robot gmapping_demo.launch.py
```

### 3. 启动RViz查看
```bash
# 新开终端
ros2 run rviz2 rviz2
```

在RViz中配置：
- Fixed Frame: `map`
- 添加LaserScan，Topic: `/scan`
- 添加Map，Topic: `/map`
- 添加TF

## 话题说明

### 发布的话题
- `/odom_combined`: 里程计信息 (nav_msgs/Odometry)
- `/scan`: 激光雷达扫描数据 (sensor_msgs/LaserScan)
- `/map`: 地图数据 (nav_msgs/OccupancyGrid)
- `/tf`: TF变换信息

### 订阅的话题
- `/cmd_vel`: 速度控制指令 (geometry_msgs/Twist)

## 控制机器人移动
```bash
# 使用键盘控制
ros2 run teleop_twist_keyboard teleop_twist_keyboard

# 或者使用自定义控制节点
ros2 launch turn_on_dlrobot_robot keyboard_control.launch.py
```

## 保存地图
```bash
# 保存地图
ros2 run nav2_map_server map_saver_cli -f ~/my_map
```

## 故障排除

### 1. TF树不完整
检查TF树：
```bash
ros2 run tf2_tools view_frames
```

### 2. 雷达数据异常
检查雷达串口：
```bash
ls -l /dev/ttyUSB*
```

### 3. 底盘通信失败
检查底盘串口：
```bash
ls -l /dev/ttyCH343USB*
```

### 4. 里程计数据异常
检查底盘驱动日志：
```bash
ros2 topic echo /odom_combined
```

## 参数调整

### Gmapping参数
编辑 `slam_gmapping/params/slam_gmapping.yaml`：
- `base_frame`: 设置为 `base_footprint`
- `odom_frame`: 设置为 `odom`
- `map_frame`: 设置为 `map`

### 底盘参数
在启动文件中可以调整：
- `serial_baud_rate`: 串口波特率
- `usart_port_name`: 串口设备名
- `robot_frame_id`: 机器人坐标系

### 雷达参数
在启动文件中可以调整：
- `serial_port`: 雷达串口
- `frame_id`: 雷达坐标系
- `angle_compensate`: 角度补偿

## 注意事项
1. 确保串口设备权限正确
2. 检查TF树是否完整
3. 确保雷达和底盘串口不冲突
4. 建图时保持机器人稳定移动
5. 避免在光线过强或过弱的环境中使用 